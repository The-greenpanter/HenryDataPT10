![HenryLogo](https://d31uz8lwfmyn8g.cloudfront.net/Assets/logo-henry-white-lg.png)

## Homework - Práctica Integradora

En el M3 se trabajó con con conjunto de datos que simulaban una empresa de venta de productos, deberás tomar ese mismo proceso de ETL y realizarlo con las herramientas Big Data que se verán en este módulo. Para esto, se provee de un entorno integrador:
https://github.com/soyHenry/DS-M4-Herramientas_Big_Data

Verificar dentro de la práctica integradora, cuáles son las imágenes que se utilizan, y qué volúmenes, y cómo se podría persisitir todo lo que se vaya trabajando dentro de los contenedores.